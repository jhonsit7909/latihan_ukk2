CREATE DATABASE buku ;

CREATE TABLE(
    id INT PRIMARY NOT NULL,
    nama_pengarang VARCHAR(255) not null,
    tahun_terbit VARCHAR(255) not null,
    no_ibsn INT(11) not null,
    jenis_buku VARCHAR(64) not null,
    judul_buku varchar(255) not null
);

CREATE table(
    id int PRIMARY key not null,
    username VARCHAR(255) not null,
    password VARCHAR(255) not null
);