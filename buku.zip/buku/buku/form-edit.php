<?php

    include("login/config.php");

    // kalau tidak ada id di query string
    if( !isset($_GET['id']) ){
        header('Location: home-page.php');
    }

    //ambil id dari query string
    $id = $_GET['id'];

    // buat query untuk ambil data dari database
    $sql = "SELECT * FROM ukk_buku WHERE id=$id";
    $query = mysqli_query($conn, $sql);
    $ukk_buku = mysqli_fetch_assoc($query);

    // jika data yang di-edit tidak ditemukan
    if( mysqli_num_rows($query) < 1 ){
        die("data tidak ditemukan...");
    }

?>


<!DOCTYPE html>
<html>
<head>
    <title>Formulir Edit Buku</title>
    <link rel="stylesheet" href="form.css">
</head>

<body >
    <header>
        <h1>Formulir Edit Buku</h1>
    </header>

    <form action="proses-edit.php" method="POST">

        <fieldset>

            <input type="hidden" name="id" value="<?php echo $ukk_buku['id'] ?>" />

        <p>
            <label for="nama_pengarang">Nama peangarang  </label>
            <input type="text" name="nama_pengarang" placeholder="nama pengarang" value="<?php echo $ukk_buku['nama_pengarang'] ?>" />
        </p>
        <p>
            <label for="penerbit">Penerbit </label>
            <input type="text" name="penerbit" value="<?php echo $ukk_buku['penerbit'] ?>">
        </p>
        <p>
            <label for="tahun_terbit">tahun penerbit  </label>
            <label><input type="text" name="tahun_terbit" value="<?php echo $ukk_buku['tahun_terbit'] ?>"></label>
        </p>
        <p>
            <label for="no_ibsn">IBSN  </label>
            <label><input type="text" name="no_ibsn" value="<?php echo $ukk_buku['no_ibsn'] ?>"></label>
        </p>
        <p>
            <label for="jenis_buku">Jenis buku </label>
            <?php $jbk = $ukk_buku['jenis_buku']; ?>
            <select selected name="jenis_buku">
                <option <?php echo ($ukk_buku == 'fiksi') ? "selected": "" ?>>Fiksi</option>
                <option <?php echo ($ukk_buku == 'Non Fiksi') ? "selected": "" ?>>Non Fiksi</option>
            </select>
        </p>
        <p>
            <label for="judul_buku">Judul Buku </label>
            <input type="text" name="judul_buku" placeholder="judul_buku" value="<?php echo $ukk_buku['judul_buku'] ?>" />
        </p>
        <p>
        <button type="submit" value="Simpan" name="simpan">Simpan</button>
        </p>

        </fieldset>


    </form>

    <div class="input-group">
        <a href="list-siswa.php" class="btn">Tabel</a>
    </div>
    </body>
</html>