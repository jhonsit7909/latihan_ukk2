<!DOCTYPE html>
<html>
<head>
    <title>Formulir Pendaftaran Siswa Baru | SMK Coding</title>
    <link rel="stylesheet" href="form.css">
</head>

<body>
    <header>
        <h1>Formulir Pendaftaran Buku Baru</h1>
    </header>

    <form action="proses-pendaftaran.php" method="POST">

        <fieldset>

        <p>
            <label for="nama_pengarang">Nama Pengarang </label>
            <input type="text" name="nama_pengarang" placeholder="Nama pengarang" />
        </p>
        <p>
            <label for="penerbit">Penerbit </label>
            <input type="text" name="penerbit">
        </p>
        <p>
            <label for="tahun_terbit">Tahun Terbit </label>
            <label><input type="text" name="tahun_terbit" ></label>
        </p>
        <p>
            <label for="no_ibsn">No IBSN </label>
            <label><input type="text" name="no_ibsn" ></label>
        </p>
        <p>
            <label for="jenis_buku">Jenis Buku </label>
            <select name="jenis_buku">
                <option></option>
                <option>Fiksi</option>
                <option>Non Fiksi</option>
            </select>
        </p>
        <p>
            <label for="judul_buku">Judul Buku </label>
            <input type="text" name="judul_buku" placeholder="judul_buku" />
        </p>
        <p>
            <button type="submit" value="Daftar" name="daftar">Daftar</button>
            <button class="tombol"><a href="Home-page.php" class="tombol" style="text-decoration:none">Halaman Utama</a></button>       
        </p>
           
        </fieldset>
        
    </form>
            
    </body>
</html>
