<?php

include('login/config.php');

// cek apakah tombol simpan sudah diklik atau blum?
if(isset($_POST['simpan'])){    

    // ambil data dari formulir
    $id = $_POST['id'];
    $nama = $_POST['nama_pengarang'];
    $penerbit = $_POST['penerbit'];
    $tahun = $_POST['tahun_terbit'];
    $ibsn = $_POST['no_ibsn'];
    $jbk = $_POST['jenis_buku'];
    $judul = $_POST['judul_buku'];

    // buat query update
    $sql = "UPDATE ukk_buku SET nama_pengarang='$nama', penerbit='$penerbit', tahun_terbit='$tahun',no_ibsn='$ibsn',jenis_buku='$jbk', judul_buku='$judul' WHERE id=$id";
    $query = mysqli_query($conn, $sql);

    // apakah query update berhasil?
    if( $query ) {
        // kalau berhasil alihkan ke halaman list-siswa.php
        header('Location: home-page.php');
    } else {
        // kalau gagal tampilkan pesan
        die("Gagal menyimpan perubahan...");
    }


} else {
    die("Akses dilarang...");
}

?>