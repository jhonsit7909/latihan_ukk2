<?php

include('login/config.php');

// cek apakah tombol daftar sudah diklik atau blum?
if(isset($_POST['daftar'])){ //jika button daftar di klik

    // ambil data dari formulir
    $nama = $_POST['nama_pengarang'];
    $penerbit = $_POST['penerbit'];
    $tahun = $_POST['tahun_terbit'];
    $ibsn = $_POST['no_ibsn'];
    $jbk = $_POST['jenis_buku'];
    $judul = $_POST['judul_buku'];

    // buat query
    $sql = "INSERT INTO ukk_buku (nama_pengarang, penerbit, tahun_terbit, no_ibsn, jenis_buku, judul_buku) VALUE ('$nama', '$penerbit', '$tahun', '$ibsn', '$jbk', '$judul')";
    $query = mysqli_query($conn, $sql);

    // apakah query simpan berhasil?
    if( $query ) {
        // kalau berhasil alihkan ke halaman index.php dengan status=sukses
        header('Location: home-page.php?status=sukses');
    } else {
        // kalau gagal alihkan ke halaman indek.php dengan status=gagal
        header('Location: home-page.php?status=gagal');
    }


} else {
    die("Akses dilarang...");
}

?>